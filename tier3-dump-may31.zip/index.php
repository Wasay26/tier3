<?php
date_default_timezone_set('Asia/Kolkata');
error_reporting(0);

// ─── Include Elasticsearch Client ─────────────────────────────────────────────
require __DIR__ . '/elastic/vendor/autoload.php';

use Elasticsearch\ClientBuilder;

$esClient = ClientBuilder::create()
    ->setHosts(['https://elastic:Hary1011!@elastic.way2mail.in:9200'])
    ->build();

// ─── Configurations ───────────────────────────────────────────────────────────
define('CIPHER_METHOD',     'AES-128-CTR');
define('ENCRYPTION_IV',     '1234567891234567');
define('ENCRYPTION_KEY',    'sfbfgbfgbcfgbfgdbfgdbfrgbfgdbgfbgfbfgdgbffgbfgb');
define('ENDPOINT',          'review1.in');
define('CACHE_DIR',         './cache/');

$today = date('Y-m-d');

// ─── Redirect helper ──────────────────────────────────────────────────────────
function redirectTo($url, $statusCode = 302)
{
    header('Location: ' . $url, true, $statusCode);
    exit;
}

// ─── Encryption helpers ───────────────────────────────────────────────────────
function encrypt($token)
{
    $encrypted = openssl_encrypt($token, CIPHER_METHOD, ENCRYPTION_KEY, 0, ENCRYPTION_IV);
    return strtr($encrypted, '+/=', '._-');
}

function decrypt($token)
{
    $decodedToken = strtr($token, '._-', '+/=');
    return openssl_decrypt($decodedToken, CIPHER_METHOD, ENCRYPTION_KEY, 0, ENCRYPTION_IV);
}

function base64url_encode($data)
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode($data)
{
    return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
}

// ─── IP helper ────────────────────────────────────────────────────────────────
function getClientIp()
{
    foreach (
        [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ] as $key
    ) {
        if (!empty($_SERVER[$key])) {
            return $_SERVER[$key];
        }
    }
    return 'UNKNOWN';
}

// ─── Fetch URL data from Elasticsearch (no MySQL) ────────────────────────────
function fetchUrlData($idField, $idValue)
{
    global $esClient;

    // 1) Try cache
    $cacheFile = CACHE_DIR . 'backup_' . $idValue . '.json';
    if (
        file_exists($cacheFile) &&
        ($cacheData = json_decode(file_get_contents($cacheFile), true)) &&
        !empty($cacheData['site_name'])
    ) {
        return $cacheData;
    }

    // 2) Query ES
    try {
        $params = [
            'index' => 'masking_urls',
            'body'  => [
                'size' => 1,
                'query' => [
                    'term' => [
                        // use .keyword for exact match on string fields
                        "{$idField}.keyword" => $idValue
                    ]
                ]
            ]
        ];
        $res = $esClient->search($params);
        if (!empty($res['hits']['hits'][0]['_source'])) {
            $source = $res['hits']['hits'][0]['_source'];
            // cache it
            if (!is_dir(CACHE_DIR)) {
                @mkdir(CACHE_DIR, 0755, true);
            }
            file_put_contents($cacheFile, json_encode($source));
            return $source;
        }
    } catch (\Exception $e) {
        // optionally log $e->getMessage()
    }

    return null;
}

// ─── Log opens or clicks into Elasticsearch ───────────────────────────────────
function logOpens($r, $response, $rcol, $complete_url, $website_root, $link_token)
{
    global $esClient, $today;

    $index = (strpos($response['redirect_destination'] ?? '', 'read.png') !== false)
        ? 'email_opened'
        : 'links_opened';

    $final_link = explode("?utm_source", $response['redirect_destination'])[0];

    $doc = [
        $rcol                 => $r,
        'opened_at'           => date('c'),
        'opened_date'           => $today,
        'strdateinfo'         => time(),
        'ip_address'          => getClientIp(),
        'current_url'          => $complete_url,
        'redirect_destination' => $response['redirect_destination'] ?? '',
        'final_link'           => $final_link,
        'site_domain'         => $response['site_domain'] ?? '',
        'site_name'           => $response['site_name'] ?? '',
        'campaign_name'       => $response['campaign_name'] ?? '',
        'campaignid'          => $response['campaignid'] ?? '',
        'campaign_reference'  => $response['campaign_reference'] ?? '',
        'campaign_ran_on'  => $response['created_at'] ?? '',
        'strdateinfo'  => $response['strdateinfo'] ?? 0,
        'campaign_date'  => $response['campaign_date'] ?? '',
        'website_root'  => $website_root,
        'link_token'  => $link_token,
    ];

    try {
        $esClient->index([
            'index' => $index,
            'body'  => $doc
        ]);

        // print_r($log_response); exit;
    } catch (\Exception $e) {
        // optionally log $e->getMessage()
    }
}

// ─── Main logic (UNCHANGED) ───────────────────────────────────────────────────
$current_url = trim($_SERVER['REQUEST_URI'], '/');
$website_root = $_SERVER['HTTP_HOST'];
$complete_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $website_root . $_SERVER['REQUEST_URI'];

$current_url_pcs = explode('/', $current_url);
$param_1 = $current_url_pcs[0] ?? '';
$param_2 = $current_url_pcs[1] ?? '';
$param_3 = $current_url_pcs[2] ?? ''; // expected to be email address if present

if (!empty($param_2) && $param_2[0] !== '?') {
    $response = fetchUrlData('link_token', $param_2);
    if (!empty($response['redirect_destination'])) {
        if (filter_var($param_3, FILTER_VALIDATE_EMAIL)) {
            logOpens($param_3, $response, 'recipient', $complete_url, $website_root, $param_2);
        } elseif (ctype_digit($param_3)) {
            logOpens($param_3, $response, 'list_data_id', $complete_url, $website_root, $param_2);
        }
        redirectTo($response['redirect_destination'], 301);
        exit;
    }

    if (strpos($_SERVER['REQUEST_URI'], '/?') !== false) {
        $request = array_keys($_REQUEST);
        if (isset($request[0])) {
            $crypted_token = ltrim(urldecode($_SERVER['REQUEST_URI']), "/?");
            file_put_contents("logs.txt", urldecode($_SERVER['REQUEST_URI']) . PHP_EOL, FILE_APPEND);
            $originaltoken_copy = $crypted_token;
            if ($crypted_token != "") {
                $crypted_token = explode("&", $crypted_token)[0];
            }
            $crypted_token = str_replace("%20", "+", $crypted_token);
            $crypted_token = str_replace(" ", "+", $crypted_token);
            $final_destination = decrypt($crypted_token);
            redirectTo($final_destination);
        }
    }
    exit;
}

$request = array_keys($_REQUEST);
if (!empty($request[0])) {
    $crypted_token = str_replace(["%20", " "], "+", explode("&", urldecode($_SERVER['REQUEST_URI']))[0]);
    file_put_contents("logs.txt", urldecode($_SERVER['REQUEST_URI']) . PHP_EOL, FILE_APPEND);

    if (isset($_GET['ur'])) {
        $response = fetchUrlData('ID', decrypt($crypted_token));
        if (!empty($response['redirect_destination'])) {
            if (filter_var($param_3, FILTER_VALIDATE_EMAIL)) {
                logOpens($param_3, $response, 'recipient', $complete_url, $website_root, '');
            } elseif (ctype_digit($param_3)) {
                logOpens($param_3, $response, 'list_data_id', $complete_url, $website_root, '');
            }
            redirectTo($response['redirect_destination'], 301);
        }

        $title      = $response['site_name'] ?? 'Please Wait';
        $post_panel = $response['site_domain'] ?? '';
    } else {
        $final_destination = isset($_REQUEST['bs4'])
            ? base64url_decode($crypted_token)
            : decrypt($crypted_token);
    }
?>
    <html>

    <head>
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-R5K20JCF72"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());
            gtag('config', 'G-R5K20JCF72');
            <?php if (isset($response)): ?>
                gtag('set', {
                    'campaign_name': '<?= strtolower(str_replace([" ", "(", ")"], ["-", "-", "-"], trim($response['campaign_name']))) ?>',
                    'campaign_source': '<?= strtolower(str_replace(" ", "_", $response['site_name'] ?? '')) ?>',
                    'campaign_medium': 'email',
                    'campaign_term': '<?= strtolower(str_replace(".", "-", $response['site_domain'] ?? '')) ?>',
                    'campaign_id': '<?= $response['campaignid'] ?? '' ?>',
                });
            <?php endif; ?>
        </script>
        <title><?= $title ?? 'Please Wait' ?></title>
        <link href="https://fonts.googleapis.com/css?family=Titillium+Web&display=swap" rel="stylesheet">
    </head>

    <body>
        <?php if (!empty($response['redirect_destination']) || !empty($final_destination)): ?>
            <script>
                setTimeout(function() {
                    window.location.href = "<?= addslashes($response['redirect_destination'] ?? $final_destination) ?>";
                }, 500);
            </script>
        <?php else: ?>
            <script src="//<?= ENDPOINT ?>?<?= $crypted_token ?>"></script>
        <?php endif; ?>
    </body>

    </html>
<?php
    exit;
}
?>