<?php
error_reporting(0);
$fgc_status="Failed";
$db_connection="Failed";
$pdo_status="Failed";
$fgc=file_get_contents("https://api.ipify.org");
if($fgc!=""){
    $fgc_status="Working, ".$fgc;
}
if ( extension_loaded('pdo') ) {
    $pdo_status= "Working";
}

$current_url=$_SERVER['REQUEST_URI'];
$current_url_pcs=explode('/',$current_url);
$param_1="";
$param_2="";
$link_check_1="";
$link_check_2="";
$link_check_3='<a href="../mm_t3/unsubscribe/?ut=3204895181689316039188995026&email=&utm_medium=email&utm_source=saj_panel&utm_campaign=sdb-jargs-jul-14-23" target="_black">Test (Unsubscribe Link)</a>';
if(sizeof($current_url_pcs)>1){
    if(isset($current_url_pcs[1])){
        $param_1=$current_url_pcs[1];        
    }
    if(isset($current_url_pcs[2])){
        $param_2=$current_url_pcs[2];        
    }
}

function w2m_encrypt($token){
	$ciphering_value = "AES-128-CTR";   
	$iv_length = openssl_cipher_iv_length($ciphering_value);  
	$options = 0;  
	$encryption_iv_value = '1234567891234567';  
	$key = "sfbfgbfgbcfgbfgdbfgdbfrgbfgdbgfbgfbfgdgbffgbfgb";  
	$encryption_value = openssl_encrypt($token, $ciphering_value, $key, $options,$encryption_iv_value); 
	$encryption_value=strtr($encryption_value, '+/=', '._-');
	return $encryption_value;
}

function w2m_decrypt($token){
	$token=strtr($token, '._-', '+/=');
	$ciphering_value = "AES-128-CTR";   
	$iv_length = openssl_cipher_iv_length($ciphering_value);  
	$options = 0;  
	$encryption_iv_value = '1234567891234567';  
	$key = "sfbfgbfgbcfgbfgdbfgdbfrgbfgdbgfbgfbfgdgbffgbfgb";  
	$decryption_value = openssl_decrypt($token, $ciphering_value, $key, $options,$encryption_iv_value);   	
	return $decryption_value;
}


$w2m_host="119.18.62.48";
$w2m_dbuser="review1_md";
$w2m_dbpassword="Mdomain@890";
$w2m_dbname="review1_md";

try {
	$w2m_ur = new PDO("mysql:host=".$w2m_host.";dbname=".$w2m_dbname, $w2m_dbuser, $w2m_dbpassword);
	$w2m_ur->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$db_connection="Connected Successfully";
    $check_url_q=$w2m_ur->query("SELECT * FROM `masking_urls` ORDER BY RAND() LIMIT 1");			
    $check_url_r=$check_url_q->fetch();			
    $ID=$check_url_r['ID'];	
    $site_name=$check_url_r['site_name'];	
    $ID_encr=w2m_encrypt($ID);
    $link_check_1='<a href="../?'.$ID_encr.'&ur=1" target="_black">Test ('.$site_name.' Link)</a>';	

    $check_url_q=$w2m_ur->query("SELECT * FROM `masking_urls` WHERE link_token IS NOT NULL ORDER BY RAND() LIMIT 1");			
    $check_url_r=$check_url_q->fetch();			
    $link_token=$check_url_r['link_token'];	
    $site_name=$check_url_r['site_name'];	
    $link_check_2='<a href="../index.php/'.$link_token.'" target="_black">Test ('.$site_name.' Link)</a>';	
} catch(PDOException $e) {
	$db_connection="Failed";
}

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Basic Tests</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  </head>
  <body>
  <body class="bg-body-tertiary">
    <div class="container">
    <main>
        <div class="row g-5 mt-4">      
        <div class="col-md-12 col-lg-12">
            <h4 class="mb-3 text-center">Basic Tests</h4>
            <table class="table table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Check</th>
                        <th scope="col">Details</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td>Current PHP version</td>
                        <td><?=phpversion()?></td>
                    </tr> 
                    <tr <?php if($fgc_status=="Failed"){echo 'table-dark';} ?>>
                        <th scope="row">2</th>
                        <td>Testing file_get_contents</td>
                        <td><?=$fgc_status?></td>
                    </tr> 
                    <tr <?php if($pdo_status=="Failed"){echo 'table-dark';} ?>>
                        <th scope="row">3</th>
                        <td>PDO Extension</td>
                        <td><?=$pdo_status?></td>
                    </tr> 
                    <tr <?php if($db_connection=="Failed"){echo 'table-dark';} ?>>
                        <th scope="row">4</th>
                        <td>Backend Server</td>
                        <td><?=$db_connection?></td>
                    </tr>      
                    <tr>
                        <th scope="row">5</th>
                        <td>Link Check 1</td>
                        <td><?=$link_check_1?></td>
                    </tr>  
                    <tr>
                        <th scope="row">6</th>
                        <td>Link Check 2</td>
                        <td><?=$link_check_2?></td>
                    </tr>   
                    <tr>
                        <th scope="row">7</th>
                        <td>Link Check 3</td>
                        <td><?=$link_check_3?></td>
                    </tr>            
                </tbody>
                </table>
        </div>
        </div>
    </main>
    </div>
 </body>
</html>