<?php
date_default_timezone_set('Asia/Kolkata');
error_reporting(E_ALL);

// ─── Include Elasticsearch Client ─────────────────────────────────────────────
require __DIR__ . '/../../elastic/vendor/autoload.php';
use Elasticsearch\ClientBuilder;
$esClient = ClientBuilder::create()
    ->setHosts(['https://elastic:Hary1011!@elastic.way2mail.in:9200'])
    ->build();

// ─── Config & initial vars ─────────────────────────────────────────────────────
$endpoint      = "review1.in";
$today         = date('F, d Y h:i A');
$email         = isset($_GET['email']) ? trim($_GET['email']) : '';
if ($email === "[EMAIL]") {
    $email = "";
}
$company_name  = "";
$work          = 0;
$campaign      = 0;
$post_panel    = "";
$response      = [];

/**
 * Fetch unsubscribe details from Elasticsearch (or cache).
 */
function campaign_details(string $unsubscribe_token): array {
    global $esClient;

    $cacheFile = __DIR__ . '/../../cache/unsub_' . $unsubscribe_token . '.json';
    if (file_exists($cacheFile) && ($data = json_decode(file_get_contents($cacheFile), true))) {
        return $data;
    }

    try {
        $res = $esClient->search([
            'index' => 'unsubscribes',
            'body'  => [
                'size' => 1,
                'query' => [
                    'term' => [
                        'unsubscribe_token.keyword' => $unsubscribe_token
                    ]
                ]
            ]
        ]);

        if (!empty($res['hits']['hits'][0]['_source'])) {
            $src = $res['hits']['hits'][0]['_source'];
            $out = [
                'work'           => $src['wid']             ?? 0,
                'campaign'       => $src['campaignid']      ?? 0,
                'company_name'   => $src['site_name']       ?? '',
                'post_panel'     => $src['site_domain']     ?? '',
                'campaign_name'  => $src['campaign_name']   ?? '',
                'unsubscribe_token' => $unsubscribe_token
            ];
            if (!is_dir(dirname($cacheFile))) {
                @mkdir(dirname($cacheFile), 0755, true);
            }
            file_put_contents($cacheFile, json_encode($out));
            return $out;
        }
    } catch (\Exception $e) {
        // optional: log $e->getMessage()
    }

    return [
        'work'           => 0,
        'campaign'       => 0,
        'company_name'   => '',
        'post_panel'     => '',
        'unsubscribe_token' => $unsubscribe_token
    ];
}

// ─── Main “ut” flow ────────────────────────────────────────────────────────────
if (isset($_GET['ut'])) {
    $ut = $_GET['ut'];
    if ($ut === "") {
        echo "something is wrong";
        exit;
    }

    // Try cache / ES
    $response = campaign_details($ut);

    if (!empty($response['post_panel'])) {
        $work         = $response['work'];
        $company_name = $response['company_name'];
        $campaign     = $response['campaign'];
        $post_panel   = $response['post_panel'];
    } else {
        // Fallback to your JSON‐endpoint
        $json = @file_get_contents("https://{$endpoint}/?{$ut}&ut&json");
        if ($json) {
            $response     = json_decode($json, true);
            $work         = $response['work'];
            $company_name = $response['company_name'];
            $campaign     = $response['campaign'];
            $post_panel   = $response['post_panel'];
            file_put_contents(__DIR__ . '/../../cache/unsub_' . $ut . '.json', json_encode($response));
        }
    }
} else {
    exit;
}
?>


<!DOCTYPE html>

<html>

	<head>

  		<meta charset="utf-8">

  		<meta http-equiv="X-UA-Compatible" content="IE=edge">

		<link rel="shortcut icon" type="image/x-icon" href="/images/favicon-md.ico" />

		

  		<title><?php if($company_name==""){ echo "Unsubscribe";}else{echo $company_name." | Unsubscribe";} ?></title>

  		<!-- Tell the browser to be responsive to screen width -->

  		<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

		  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=G-R5K20JCF72"></script>

    <script>

        window.dataLayer = window.dataLayer || [];

        function gtag(){dataLayer.push(arguments);}

        gtag('js', new Date());

        gtag('config', 'G-R5K20JCF72');

        

    </script>

    <?php

       if(isset($response['post_panel']) && $response['post_panel']!=""){

           ?>

           <script>

        gtag('set', {

    	    'campaign_name': '<?=strtolower(str_replace(")","-",str_replace("(","-",str_replace(" ","-",trim($response['campaign_name'])))))?>',

            'campaign_source': '<?=strtolower(str_replace(" ","_",$response['company_name']))?>',

            'campaign_medium': 'email',

            'campaign_term': '<?=strtolower(str_replace(".","-",$response['post_panel']))?>',

            'campaign_id': '<?=$response['campaign']?>',

        });   

        </script>

           <?php

         }else{

    ?>

    <script src="//<?=$endpoint?>?<?=$ut?>&ut=1&js=1"></script>

    <?php 

        }

    ?>

		<style>



html,body{height:100%}.content-wrapper,.main-footer{-webkit-transition:-webkit-transform .3s ease-in-out,margin .3s ease-in-out;-moz-transition:-moz-transform .3s ease-in-out,margin .3s ease-in-out;-o-transition:-o-transform .3s ease-in-out,margin .3s ease-in-out;transition:transform .3s ease-in-out,margin .3s ease-in-out;margin-left:230px;z-index:820}.layout-top-nav .content-wrapper,.layout-top-nav .main-footer{margin-left:0}@media (max-width:767px){.content-wrapper,.main-footer{margin-left:0}}@media (min-width:768px){.sidebar-collapse .content-wrapper,.sidebar-collapse .main-footer{margin-left:0}}@media (max-width:767px){.sidebar-open .content-wrapper,.sidebar-open .main-footer{-webkit-transform:translate(230px, 0);-ms-transform:translate(230px, 0);-o-transform:translate(230px, 0);transform:translate(230px, 0)}}.content-wrapper{min-height:100%;background-color:#ecf0f5;z-index:800}.main-footer{background:#fff;padding:15px;color:#444;border-top:1px solid #d2d6de}.fixed .main-header,.fixed .main-sidebar,.fixed .left-side{position:fixed}.fixed .main-header{top:0;right:0;left:0}.fixed .content-wrapper,.fixed .right-side{padding-top:50px}@media (max-width:767px){.fixed .content-wrapper,.fixed .right-side{padding-top:100px}}.fixed.layout-boxed .wrapper{max-width:100%}.fixed .wrapper{overflow:hidden}.hold-transition .content-wrapper,.hold-transition .right-side,.hold-transition .main-footer,.hold-transition .main-sidebar,.hold-transition .left-side,.hold-transition .main-header .navbar,.hold-transition .main-header .logo,.hold-transition .menu-open .fa-angle-left{-webkit-transition:none;-o-transition:none;transition:none}.content{min-height:250px;padding:15px;margin-right:auto;margin-left:auto;padding-left:15px;padding-right:15px}h1,h2,h3,h4,h5,h6,.h1,.h2,.h3,.h4,.h5,.h6{font-family:'Source Sans Pro',sans-serif}a{color:#3c8dbc}a:hover,a:active,a:focus{outline:none;text-decoration:none;color:#72afd2}.page-header{margin:10px 0 20px 0;font-size:22px}.page-header>small{color:#666;display:block;margin-top:5px}.main-header{position:relative;max-height:100px;z-index:1030}.main-header .navbar{-webkit-transition:margin-left .3s ease-in-out;-o-transition:margin-left .3s ease-in-out;transition:margin-left .3s ease-in-out;margin-bottom:0;margin-left:230px;border:none;min-height:50px;border-radius:0}.layout-top-nav .main-header .navbar{margin-left:0}.main-header #navbar-search-input.form-control{background:rgba(255,255,255,0.2);border-color:transparent}.main-header #navbar-search-input.form-control:focus,.main-header #navbar-search-input.form-control:active{border-color:rgba(0,0,0,0.1);background:rgba(255,255,255,0.9)}.main-header #navbar-search-input.form-control::-moz-placeholder{color:#ccc;opacity:1}.main-header #navbar-search-input.form-control:-ms-input-placeholder{color:#ccc}.main-header #navbar-search-input.form-control::-webkit-input-placeholder{color:#ccc}.main-header .navbar-custom-menu,.main-header .navbar-right{float:right}@media (max-width:991px){.main-header .navbar-custom-menu a,.main-header .navbar-right a{color:inherit;background:transparent}}@media (max-width:767px){.main-header .navbar-right{float:none}.navbar-collapse .main-header .navbar-right{margin:7.5px -15px}.main-header .navbar-right>li{color:inherit;border:0}}.main-header .sidebar-toggle{float:left;background-color:transparent;background-image:none;padding:15px 15px;font-family:fontAwesome}.main-header .sidebar-toggle:before{content:"\f0c9"}.main-header .sidebar-toggle:hover{color:#fff}.main-header .sidebar-toggle:focus,.main-header .sidebar-toggle:active{background:transparent}.main-header .sidebar-toggle .icon-bar{display:none}.main-header .navbar .nav>li.user>a>.fa,.main-header .navbar .nav>li.user>a>.glyphicon,.main-header .navbar .nav>li.user>a>.ion{margin-right:5px}.main-header .navbar .nav>li>a>.label{position:absolute;top:9px;right:7px;text-align:center;font-size:9px;padding:2px 3px;line-height:.9}.main-header .logo{-webkit-transition:width .3s ease-in-out;-o-transition:width .3s ease-in-out;transition:width .3s ease-in-out;display:block;float:left;height:50px;font-size:20px;line-height:50px;text-align:center;width:230px;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;padding:0 15px;font-weight:300;overflow:hidden}.main-header .logo .logo-lg{display:block}.main-header .logo .logo-mini{display:none}.main-header .navbar-brand{color:#fff}.content-header{position:relative;padding:15px 15px 0 15px}.content-header>h1{margin:0;font-size:24px}.content-header>h1>small{font-size:15px;display:inline-block;padding-left:4px;font-weight:300}.content-header>.breadcrumb{float:right;background:transparent;margin-top:0;margin-bottom:0;font-size:12px;padding:7px 5px;position:absolute;top:15px;right:10px;border-radius:2px}.content-header>.breadcrumb>li>a{color:#444;text-decoration:none;display:inline-block}.content-header>.breadcrumb>li>a>.fa,.content-header>.breadcrumb>li>a>.glyphicon,.content-header>.breadcrumb>li>a>.ion{margin-right:5px}.content-header>.breadcrumb>li+li:before{content:'>\00a0'}@media (max-width:991px){.content-header>.breadcrumb{position:relative;margin-top:5px;top:0;right:0;float:none;background:#d2d6de;padding-left:10px}.content-header>.breadcrumb li:before{color:#97a0b3}}.small-box{border-radius:2px;position:relative;display:block;margin-bottom:20px;box-shadow:0 1px 1px rgba(0,0,0,0.1)}.small-box>.inner{padding:10px}.small-box>.small-box-footer{position:relative;text-align:center;padding:3px 0;color:#fff;color:rgba(255,255,255,0.8);display:block;z-index:10;background:rgba(0,0,0,0.1);text-decoration:none}.small-box>.small-box-footer:hover{color:#fff;background:rgba(0,0,0,0.15)}.small-box h3{font-size:38px;font-weight:bold;margin:0 0 10px 0;white-space:nowrap;padding:0}.small-box p{font-size:15px}.small-box p>small{display:block;color:#f9f9f9;font-size:13px;margin-top:5px}.small-box h3,.small-box p{z-index:5}.small-box .icon{-webkit-transition:all .3s linear;-o-transition:all .3s linear;transition:all .3s linear;position:absolute;top:-10px;right:10px;z-index:0;font-size:90px;color:rgba(0,0,0,0.15)}.small-box:hover{text-decoration:none;color:#f9f9f9}.small-box:hover .icon{font-size:95px}@media (max-width:767px){.small-box{text-align:center}.small-box .icon{display:none}.small-box p{font-size:12px}}.box{position:relative;border-radius:3px;background:#ffffff;border-top:3px solid #d2d6de;margin-bottom:20px;width:100%;box-shadow:0 1px 1px rgba(0,0,0,0.1)}.box.box-primary{border-top-color:#3c8dbc}.box.box-info{border-top-color:#00c0ef}.box.box-danger{border-top-color:#dd4b39}.box.box-warning{border-top-color:#f39c12}.box.box-success{border-top-color:#00a65a}.box.box-default{border-top-color:#d2d6de}.box.collapsed-box .box-body,.box.collapsed-box .box-footer{display:none}.box .nav-stacked>li{border-bottom:1px solid #f4f4f4;margin:0}.box .nav-stacked>li:last-of-type{border-bottom:none}.box.height-control .box-body{max-height:300px;overflow:auto}.box .border-right{border-right:1px solid #f4f4f4}.box .border-left{border-left:1px solid #f4f4f4}.box.box-solid{border-top:0}.box.box-solid>.box-header .btn.btn-default{background:transparent}.box.box-solid>.box-header .btn:hover,.box.box-solid>.box-header a:hover{background:rgba(0,0,0,0.1)}.box.box-solid.box-default{border:1px solid #d2d6de}.box.box-solid.box-default>.box-header{color:#444;background:#d2d6de;background-color:#d2d6de}.box.box-solid.box-default>.box-header a,.box.box-solid.box-default>.box-header .btn{color:#444}.box.box-solid.box-primary{border:1px solid #3c8dbc}.box.box-solid.box-primary>.box-header{color:#fff;background:#3c8dbc;background-color:#3c8dbc}.box.box-solid.box-primary>.box-header a,.box.box-solid.box-primary>.box-header .btn{color:#fff}.box.box-solid.box-info{border:1px solid #00c0ef}.box.box-solid.box-info>.box-header{color:#fff;background:#00c0ef;background-color:#00c0ef}.box.box-solid.box-info>.box-header a,.box.box-solid.box-info>.box-header .btn{color:#fff}.box.box-solid.box-danger{border:1px solid #dd4b39}.box.box-solid.box-danger>.box-header{color:#fff;background:#dd4b39;background-color:#dd4b39}.box.box-solid.box-danger>.box-header a,.box.box-solid.box-danger>.box-header .btn{color:#fff}.box.box-solid.box-warning{border:1px solid #f39c12}.box.box-solid.box-warning>.box-header{color:#fff;background:#f39c12;background-color:#f39c12}.box.box-solid.box-warning>.box-header a,.box.box-solid.box-warning>.box-header .btn{color:#fff}.box.box-solid.box-success{border:1px solid #00a65a}.box.box-solid.box-success>.box-header{color:#fff;background:#00a65a;background-color:#00a65a}.box.box-solid.box-success>.box-header a,.box.box-solid.box-success>.box-header .btn{color:#fff}.box.box-solid>.box-header>.box-tools .btn{border:0;box-shadow:none}.box.box-solid[class*='bg']>.box-header{color:#fff}.box .box-group>.box{margin-bottom:5px}.box .knob-label{text-align:center;color:#333;font-weight:100;font-size:12px;margin-bottom:0.3em}.box>.overlay,.overlay-wrapper>.overlay,.box>.loading-img,.overlay-wrapper>.loading-img{position:absolute;top:0;left:0;width:100%;height:100%}.box .overlay,.overlay-wrapper .overlay{z-index:50;background:rgba(255,255,255,0.7);border-radius:3px}.box .overlay>.fa,.overlay-wrapper .overlay>.fa{position:absolute;top:50%;left:50%;margin-left:-15px;margin-top:-15px;color:#000;font-size:30px}.box .overlay.dark,.overlay-wrapper .overlay.dark{background:rgba(0,0,0,0.5)}.box-header:before,.box-body:before,.box-footer:before,.box-header:after,.box-body:after,.box-footer:after{content:" ";display:table}.box-header:after,.box-body:after,.box-footer:after{clear:both}.box-header{color:#444;display:block;padding:10px;position:relative}.box-header.with-border{border-bottom:1px solid #f4f4f4}.collapsed-box .box-header.with-border{border-bottom:none}.box-header>.fa,.box-header>.glyphicon,.box-header>.ion,.box-header .box-title{display:inline-block;font-size:18px;margin:0;line-height:1}.box-header>.fa,.box-header>.glyphicon,.box-header>.ion{margin-right:5px}.box-header>.box-tools{position:absolute;right:10px;top:5px}.box-header>.box-tools [data-toggle="tooltip"]{position:relative}.box-header>.box-tools.pull-right .dropdown-menu{right:0;left:auto}.box-header>.box-tools .dropdown-menu>li>a{color:#444!important}.btn-box-tool{padding:5px;font-size:12px;background:transparent;color:#97a0b3}.open .btn-box-tool,.btn-box-tool:hover{color:#606c84}.btn-box-tool.btn:active{box-shadow:none}.box-body{border-top-left-radius:0;border-top-right-radius:0;border-bottom-right-radius:3px;border-bottom-left-radius:3px;padding:10px}.no-header .box-body{border-top-right-radius:3px;border-top-left-radius:3px}.box-body>.table{margin-bottom:0}.box-body .fc{margin-top:5px}.box-body .full-width-chart{margin:-19px}.box-body.no-padding .full-width-chart{margin:-9px}.box-body .box-pane{border-top-left-radius:0;border-top-right-radius:0;border-bottom-right-radius:0;border-bottom-left-radius:3px}.box-body .box-pane-right{border-top-left-radius:0;border-top-right-radius:0;border-bottom-right-radius:3px;border-bottom-left-radius:0}.box-footer{border-top-left-radius:0;border-top-right-radius:0;border-bottom-right-radius:3px;border-bottom-left-radius:3px;border-top:1px solid #f4f4f4;padding:10px;background-color:#fff}.chart-legend{margin:10px 0}@media (max-width:991px){.chart-legend>li{float:left;margin-right:10px}}.box-comments{background:#f7f7f7}.box-comments .box-comment{padding:8px 0;border-bottom:1px solid #eee}.box-comments .box-comment:before,.box-comments .box-comment:after{content:" ";display:table}.box-comments .box-comment:after{clear:both}.box-comments .box-comment:last-of-type{border-bottom:0}.box-comments .box-comment:first-of-type{padding-top:0}.box-comments .box-comment img{float:left}.box-comments .comment-text{margin-left:40px;color:#555}.box-comments .username{color:#444;display:block;font-weight:600}.box-comments .text-muted{font-weight:400;font-size:12px}

 

		</style>

		<!-- Google tag (gtag.js) -->

        

	</head>

	<body class="hold-transition skin-blue sidebar-mini">

	<!-- Site wrapper -->

	



		  <div class="content-wrapper-misc">

        	   <!-- Content Header (Page header) --> 

	

<!--div class="rht_menu2" style="min-height:500px">-->

<div class="container-fluid1">

	

	 <section class="content1">

<div id="way2buy_top_banner_1"></div>	

<form action="" class="form" id="subscribe" enctype="multipart/form-data" method="post" accept-charset="utf-8">	

		<div class="">

				<div class="col-md-1"></div>

				<div class="col-md-7">

					<section class="content-header" style="margin-bottom: 5px;">

							<h1 class="text-center"> Subscriptions <small>Manage</small></h1>

					</section> 

					<div class="box box-primary box-solid">

						<div class="box-header with-border">

							<h3 class="box-title" data-toggle="tooltip" data-placement="top" title="" data-original-title="Unsubscribe">Unsubscribe</h3>

						</div>

						<div class="box-body">

							<div class="row" id="unsubscribe">

								<div class="box-header with-border">

													<h3 class="box-title"><strong> Your Subscription Settings</strong></h3>

												</div>

								<div class="tab-content">

                                        				<div id="tabs-1" class="tab-pane fade active in">

                                                				<div class="col-md-12 col-sm-12 col-xs-12">

                                                        				<div class="box box-primary">

												

                                                                				<div class="box-body">

																										<div class="row">

														<div class="col-md-12 col-sm-12">

															Hello,<br /><br />

															<?php if($email!=""){ ?>

															<p>

															If your email address is <b><?=$email?></b>, you can unsubscribe

															or modify your subscription settings using below options.

															</p>

															<?php }else{ ?>

															<p>

															you can unsubscribe

															or modify your subscription settings using below options.

															</p>

															<?php } ?>

														</div>

													</div>

													<div class="row">

													<div class="col-md-4 col-sm-12 text-right" style="padding-top: 90px;">

													<label class="control-label">Email Addressses</label>

													</div>

													<div class="col-md-7 col-sm-12"><button onClick="add_more_emails()" style="float:right;margin-bottom:5px" type="button" class="btn btn-primary">Add More Emails</button>

													<div   >

													<table class="table table-bordered" id="emails_div" style="margin-bottom:5px;">

													<thead>

													<tr>

													<td>

													Email

													</td>

													<td>

													Actions

													</td>

													</tr>

													</thead>

													<tbody>

													<tr>

													<td><input type="text" style="margin-bottom:10px" name="emails[]"  class="form-control"  placeholder="Please Enter Email" id="default_email" value="<?=$email?>" <?php if($email!=""){echo 'disabled="disabled"'; } ?>>

													

													</td>

													<td>

													<span class="check"></span>

													</td>

													</tr>

													</tbody>

													</table>

<div id="default_email_div" style="color: red;margin-top: 5px; margin-bottom:20px;"></div>	

													<!--<input type="text" style="margin-bottom:10px" name="emails[]" class="form-control"  placeholder="Please Enter Email" >-->

													</div>

													</div>

													</div>

													<div class="row">

														<div class="col-md-4 col-sm-12 text-right" style="padding-top: 4px;">

															<label class="control-label">I wish to Unsubscribe because</label>

														</div>

														<div class="col-md-7 col-sm-12">

															<select name="reason" class="form-control" id="reason">

																<option value="">--- Select Unsubscribe Reason ---</option>

																<option value="I no longer want to receive these emails">I no longer want to receive these emails</option>

																<option value="You send too many Emails">You send too many Emails</option>

																<option value="The Emails looks like Spam">The Emails looks like Spam</option>

																<option value="You send Irrelevant Content">You send Irrelevant Content</option>

																<option value="Emails not Tailored to Reader Preferences">Emails not Tailored to Reader Preferences</option>

																<option value="You're not optimizing your emails for mobile">You're not optimizing your emails for mobile</option>

																<option value="Too much Content">Too much Content</option>

																<option value="I have never Subscribed">I have never Subscribed</option>

																<option value="Other">Other</option>

															</select>				



<div id="reason_error_div" style="    color: red;

    margin-top: 5px;">

</div>										</div>

													</div>

													<div class="row" id="unsubscribe_text" style="margin-top:10px;">

														<div class="col-md-4 col-sm-12 text-right">

<label class="control-label">Message</label>                                                                                       </div>

														<div class="col-md-7 col-sm-12">

															 <textarea class="form-control" name="message" id="message"placeholder="Optional"></textarea>

														</div>

													</div>

																										<div class="row" style="margin-top:10px;">

																										

														<div class="col-md-12 col-sm-12" align="center">

					<div id="unsub_div" style="padding:10px;color:red;font-size:23px;display:none">Unsubscribed Successfully</div>										                                                									<button name="unsubscribe" class="button btn btn-primary btn-sm" title="Unsubscribe" id="submit_unsubscribe" style="margin-right:10px;"  onClick="add_unsubsciber()" type="button" >Unsubscribe</button><!--<button name="close" class="button btn btn-danger btn-sm" title="Close" id="close" type="button" onClick="javascript:window.close;">Close</button>-->		

																																														</div>

													</div>

												</div>

											</div>

										</div>

										<?php if($email!=""){ ?>

										<p style="margin-top:5px;text-align:center">Please ignore if your email address is not <b><?=$email?></b>.

										<?php } ?>

														</p>		

									</div>

									

							</div>

							</div>

                        			</div>

					</div>

				</div>

				<div class="col-md-3" style="margin-top: 45px;">

					<div id="way2buy_right_banner_1"></div>

				</div>

				<div class="col-md-1"></div>

			</div>

			</form>

			<div id="way2buy_bottom_banner_1"></div>

			</section></div>

		</div>

		  <!-- Content Wrapper. Contains page content -->

		

		<!-- ./wrapper -->

<!--<script async src="//way2buy.in/banners/ads.js"></script>-->





    <div id="way2buy_left_banner_1"></div>  

    <div id="way2buy_leaderboard_banner_1"></div>

    <div id="way2buy_popup_banner_1"></div>

<script src="https://way2buy.in/banners/ads.php?site=unsubscribe"></script>

	</body>

</html>



<script>

function add_more_emails()

{

$("#emails_div").append('<tr><td style="vertical-align:middle"><input type="text" style="margin-bottom:10px" name="emails[]" class="form-control emails"  placeholder="Please Enter Email" ></td><td  style="vertical-align:middle"><span class="check"></span>  <button class="btn btn-danger btn-xs" onClick="$(this).closest(`tr`).remove();"><i class="fa fa-trash"></i></button></td></tr>');

}

</script>

<script> 

function add_unsubsciber()

{



    var reason = $("#reason").val();

	var message=$("#message").val();

    var default_email = $("#default_email").val();

    

    

    <?php

    if($post_panel!=""){

        ?>

    var post_panel="<?=$post_panel?>";

    var work=<?=$work?>;

    var campaign=<?=$campaign?>;

    var company_name="<?=$company_name?>";

        <?php

    }

    ?>

    

    

 if(default_email=='')

  {

$("#default_email_div").html('Please enter your email address');

  return false;

  }

  else

  {

  $("#default_email").html('');

  }

  

  if(reason=='')

  {

$("#reason_error_div").html('Please select reason from above list');

  return false;

  }

  else

  {

  $("#reason_error_div").html('');

  }

 if(reason!="")

 {

 	

emails = document.getElementsByName('emails[]');

var mails='';

for(var i=0;i<emails.length;i++)

{

if(i>0)

{

mails=mails+ ', ';

}

var mails=mails+ emails[i].value;

}

var encode_mails=btoa(mails);

		$(".check").html('<i class="fa fa-spinner" style="color:green"></i>');



	<?php if($email!=""){ ?>

		$("#default_email").attr('disabled',true);

		<?php } ?>

		$(".emails").attr('disabled',true);

		$(".btn").attr('disabled',true);

		$("#reason").attr('disabled',true);

		$("#message").attr('disabled',true);

		var img1 = new Image();

img1.src="//"+post_panel+"/add_unsubscribers?work="+work+"&campaign="+campaign+"&emails="+encode_mails+"&reason="+btoa(reason)+"&message="+btoa(message)+"";



var img = new Image();



 var msg=encodeURI('Company Name: '+company_name+'\nDomain: '+post_panel+'\nUnsubsciber(s): '+mails+'\nReason: '+reason+'');

if(message!="")

{

msg=msg+'\n Message: '+message+'';

}



img.src = 'https://api.telegram.org/bot328622918:AAGlrTHJbMBqGBtkWam1Rw7TxWcy6ax87ZI/sendMessage?chat_id=-490497777&text='+msg+'';

 setTimeout(function(){

    //do what you need here

	$(".check").html('<i class="fa fa-check" style="color:green"></i>');

			$("#unsub_div").css('display','block');

					$("#default_email").attr('disabled',false);

				$(".emails").attr('disabled',false);

		$(".btn").attr('disabled',false);

		$("#reason").attr('disabled',false);

		$("#message").attr('disabled',false);

}, 5000);

 /*

 var form = $('#subscribe')[0];

			var data = new FormData(form);

			

			

		$.ajax({		

		type: "POST",										

		url: "",

		dataType: 'html',

		data: data,

		enctype: 'multipart/form-data',

		processData: false,

		contentType: false,

		 cache: false,

		 

		success: function(result)

		{

		$(".check").html('<i class="fa fa-check" style="color:green"></i>');

		<?php if($email!=""){ ?>

		$("#default_email").attr('disabled',true);

		<?php } ?>

		$(".btn").attr('disabled',true);

		$("#reason").attr('disabled',true);

		$("#message").attr('disabled',true);

		$("#unsub_div").css('display','block');

	



		}



	});

	*/}



}



</script>