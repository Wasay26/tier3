<?php
require 'vendor/autoload.php';

$client = Elasticsearch\ClientBuilder::create()->build();

/*$params = [
    'index' => 'my_index',
    'id'    => 'my_id',
    'body'  => ['testField' => 'abc']
];

$response = $client->index($params);
print_r($response);

$params = [
    'index' => 'my_index',
    'id'    => 'my_id'
];

$response = $client->get($params);
print_r($response);

$params = [
    'index' => 'articles',
    'id'    => 'a_1',
    'body'  => ['article_title' => 'Hello There']
];

$response = $client->index($params);
print_r($response);

$params = [
    'index' => 'articles',
    'id'    => 'a_1'
];

$response = $client->get($params);
print_r($response);

*/

$params = [
    'index' => 'articles',
    'id'    => 'a_11',
    'body'  => ['article_title' => 'Hello There']
];

$response = $client->index($params);
print_r($response);
?>