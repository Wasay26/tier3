<?php
if(isset($_REQUEST['tc'])){
    $tc=base64_decode($_REQUEST['tc']);
    $ip = $_SERVER['REMOTE_ADDR'];
    echo file_get_contents($tc);
}else if(isset($_REQUEST['ipify'])){
    echo file_get_contents("https://api.ipify.org");
}else{
    echo "ok";
}

$w2m_host="119.18.62.48";
$w2m_dbuser="review1_md";
$w2m_dbpassword="Mdomain@890";
$w2m_dbname="review1_md";

try {
	$w2m_ur = new PDO("mysql:host=".$w2m_host.";dbname=".$w2m_dbname, $w2m_dbuser, $w2m_dbpassword);
	$w2m_ur->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	echo "Connected successfully";
} catch(PDOException $e) {
	echo "Connection failed: " . $e->getMessage();
}
?>