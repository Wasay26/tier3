<?php
require __DIR__ . '/phpmailer/PHPMailerAutoload.php';

// ——— Configuration —————————————————————————————————————————————
date_default_timezone_set('Asia/Kolkata');
ini_set('display_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/elastic/vendor/autoload.php';

use Elasticsearch\ClientBuilder;


// where to store your status file
$statusFile    = __DIR__ . '/bp_log.json';
$lockTTL    = 10 * 60; // 10 minutes

if (file_exists($statusFile)) {
	$status = json_decode(file_get_contents($statusFile), true) ?: [];
	$running = !empty($status['running']);
	$ts      = !empty($status['timestamp']) ? (int)$status['timestamp'] : 0;

	if ($running && (time() - $ts) < $lockTTL) {
		exit("⚠️ Script already running (since " . date('Y-m-d H:i:s', $ts) . ").\n");
	}
}

$status['running']   = true;
$status['timestamp'] = time();
$status['last_updated_on'] = date('Y-m-d H:i:s');

$status['log'] = [];

file_put_contents($statusFile, json_encode($status, JSON_PRETTY_PRINT));

// define the unlock function
function appendLog(array $entry)
{
	global $status, $statusFile;
	$status['log'][] = $entry;
	file_put_contents($statusFile, json_encode($status, JSON_PRETTY_PRINT));
}

/**
 * Release the lock but preserve the accumulated log
 */
function releaseLock()
{
	global $status, $statusFile;
	$status['running']   = false;
	$status['timestamp'] = time();
	$status['last_updated_on'] = date('Y-m-d H:i:s');
	file_put_contents($statusFile, json_encode($status, JSON_PRETTY_PRINT));
}

$account_name = "";
$batchSendLimit = 5;

// Detect http vs https
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
	|| ($_SERVER['SERVER_PORT'] ?? '') == 443;
$scheme  = $isHttps ? 'https' : 'http';

// Full URL (if you need it)
$currentUrl = $scheme . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

// The host exactly as in the address-bar, including all subdomains:
$fullDomain = $_SERVER['HTTP_HOST'];


if (isset($_REQUEST['account'])) {
	$account_name = trim($_REQUEST['account']);
}

$account_key = "website_root"; //website_root or account_name
$account_value = $fullDomain; //$fullDomain or $account_name

file_put_contents(__DIR__ . "/testing.txt", "Current time: " . date("Y-m-d H:i:s"));


$esHosts = [
	'https://elastic:Hary1011!@elastic.way2mail.in:9200'
];

$esClient = ClientBuilder::create()
	->setHosts($esHosts)
	->build();


//check maintenance
// Define the index to check
$maintenanceIndex = 'w2m_maintenance';

// Prepare count query to find documents with status=1
$countParams = [
	'index' => $maintenanceIndex,
	'body'  => [
		'query' => [
			'term' => [
				'status' => 1
			]
		]
	]
];

try {
	// Execute the count query
	$countResult = $esClient->count($countParams);

	// Get the count of documents with status=1
	$maintenanceCount = $countResult['count'] ?? 0;

	if ($maintenanceCount > 0) {
		echo "Maintenance work is going on<br />";
		releaseLock();
		exit;
		// You can add additional logic for when maintenance mode is on
	}
} catch (\Exception $e) {
	echo "Error checking maintenance status: " . $e->getMessage() . "<br />";
}

/////// get batch_send_limit

// Prepare search query to find the account and get batch_send_limit
$searchParams = [
	'index' => 'accounts',
	'body'  => [
		'size' => 1,
		'query' => [
			'term' => [
				$account_key . '.keyword' => $account_value
			]
		]
	]
];

try {
	// Execute the search
	$response = $esClient->search($searchParams);

	// Check if any results were found
	$hits = $response['hits']['hits'] ?? [];

	if (count($hits) > 0) {
		// Get the first (and should be only) result
		$accountData = $hits[0]['_source'];

		// Check if batch_send_limit exists in the account data
		if (isset($accountData['batch_send_limit'])) {
			$batchSendLimit = $accountData['batch_send_limit'];
			$account_name = $accountData['account_name'];
			$website_root = $accountData['website_root'];
			echo "Account: {$account_name} [{$website_root}], Batch Send Limit: {$batchSendLimit}<br />";
		} else {
			echo "Account found but batch_send_limit is not set for {$account_name} <br />";
			releaseLock();
			exit;
		}
	} else {
		echo "No account found with name: {$account_name}<br />";
		releaseLock();
		exit;
	}
} catch (\Exception $e) {
	echo "Error searching for account: " . $e->getMessage() . "<br />";
	releaseLock();
	exit;
}

if ($batchSendLimit == "0") {
	echo "can not fetch records since batch send limit is set to zero";
	releaseLock();
	exit;
}


$searchParams = [
	'index' => 'pending_mail_queue',
	'body'  => [
		'size' => $batchSendLimit,
		'query' => [
			'term' => [
				'account_name.keyword' => $account_name
			]
		],
		'sort' => [
			['strdateinfo' => ['order' => 'asc']]
		]
	]
];
$res  = $esClient->search($searchParams);
$hits = $res['hits']['hits'] ?? [];

if (empty($hits)) {
	echo "No pending records for this account " . $account_name . " [" . $website_root . "].<br />";
	releaseLock();
	exit;
}


// ——— Extract credentials from the first hit —————————————————————————
$firstCred = $hits[0]['_source']['credentials'] ?? [];
$smtpHost   = $firstCred['hostname1']  ?? '';
$smtpPort   = $firstCred['port1']      ?? 587;
$smtpUser   = $firstCred['username1']  ?? '';
$smtpPass   = $firstCred['password1']  ?? '';
$smtpSecure = $firstCred['secure1']    ?? 'tls';
$senderemail = $firstCred['senderemail']    ?? '';
$senderdomain = $firstCred['senderdomain']    ?? '';
$account_category = $firstCred['account_category']    ?? '';

if ($account_category == "dedicated_server") {
	$smtpHost = "localhost";
}


// ——— Setup PHPMailer once with SMTPKeepAlive ———————————————————————
$mail = new PHPMailer(true);
try {
	$mail->CharSet = 'UTF-8';
	$mail->isSMTP();
	$mail->Host         = $smtpHost;
	$mail->Port         = $smtpPort;
	$mail->SMTPSecure   = $smtpSecure;
	$mail->SMTPAuth     = true;
	$mail->Username     = $smtpUser;
	$mail->Password     = $smtpPass;
	$mail->SMTPKeepAlive = true;
	$mail->Timeout      = 30;
	$mail->isHTML(true);
} catch (Exception $e) {
	die("Mailer setup failed: " . $e->getMessage() . "<br />");
	releaseLock();
}

// ——— Prepare a single bulk payload —————————————————————————————
$bulk = [];
$mail_count = 1;
foreach ($hits as $hit) {
	$id  = $hit['_id'];
	$src = $hit['_source'];

	// Decode fields if needed
	$to_email_decoded    = $src['to_email_decoded'];
	$from  = $senderemail;
	$from_name_decoded  = $src['from_name_decoded'];
	$subj  = base64_decode($src['subject']);
	$body  = base64_decode($src['email_content']);
	$replyto = $src['reply_to_decoded'];
	$unsubscribe_link = $src['unsubscribe_link'];

	$list_id = $src['list_id'];
	$list_data_id = $src['list_data_id'];

	// 1) Validate recipient
	if (!filter_var($to_email_decoded, FILTER_VALIDATE_EMAIL)) {
		$error = "Invalid recipient address: {$to_email_decoded}";
		$bulk[] = ['index' => ['_index' => 'sent_report']];
		$bulk[] = array_merge($src, [
			'dateinfo' => date('Y-m-d H:i:s'),
			'strdateinfo' => time(),
			'status' => 'error',
			'message' => $error
		]);
		$bulk[] = ['delete' => ['_index' => 'pending_mail_queue', '_id' => $id]];
		continue;
	}

	// 2) Validate subject
	if (trim($subj) === '') {
		$error = "Empty or invalid subject for record {$id}";
		$bulk[] = ['index' => ['_index' => 'sent_report']];
		$bulk[] = array_merge($src, [
			'dateinfo' => date('Y-m-d H:i:s'),
			'strdateinfo' => time(),
			'status' => 'error',
			'message' => $error
		]);
		$bulk[] = ['delete' => ['_index' => 'pending_mail_queue', '_id' => $id]];
		continue;
	}


	if ($senderemail != "") {
		//default because it is properly configured with dkim, spf, dmarc
		$fromemail = $senderemail; // forcing sender email as from email
	}

	if ($replyto != "") {
		$replyto_domain = trim(explode("@", $replyto)[1]);
		$fromemail_domain = trim(explode("@", $fromemail)[1]);
		if (strtolower($replyto_domain) == strtolower($fromemail_domain)) {
			//if both domains are same, replyto email address is eligible to come as from email since the domain is configured with dkim, spf, dmarc
			$fromemail = $replyto;
		}
	}

	//email from name
	if (isset($from_name_decoded)) {
		if ($from_name_decoded == "") {
			$from_name_decoded = $fromemail;
		}
	} else {
		$from_name_decoded = $fromemail;
	}

	// Configure recipients & content
	$mail->clearAddresses();
	$mail->clearReplyTos();
	$mail->clearAttachments();
	$mail->clearCustomHeaders();
	$mail->Sender = $senderemail;
	$mail->setFrom($fromemail, $from_name_decoded);
	// $mail->addAddress($to_email_decoded);
	// $mail->addAddress("test-e3n10sl9o" . $mail_count . "@srv1.mail-tester.com");

	try {
		$mail->addAddress($to_email_decoded);
	} catch (Exception $e) {
		// invalid address caught by PHPMailer
		$error = "PHPMailer invalid address: " . $e->getMessage();
		$bulk[] = ['index' => ['_index' => 'sent_report']];
		$bulk[] = array_merge($src, [
			'dateinfo' => date('Y-m-d H:i:s'),
			'strdateinfo' => time(),
			'status' => 'error',
			'message' => $error
		]);
		$bulk[] = ['delete' => ['_index' => 'pending_mail_queue', '_id' => $id]];
		continue;
	}


	if ($replyto != "") {
		$mail->addReplyTo($replyto);
	}

	$mail->Subject = $subj;
	$mail->Body    = $body;

	$mail->XMailer = ' ';

	$email_message_id = sprintf(
		'<%s%s%s@%s>',
		time(),
		$list_id,
		$list_data_id,
		$senderdomain
	);

	$mail->MessageID = $email_message_id;
	if ($unsubscribe_link == "") {
		$mail->addCustomHeader(
			'List-Unsubscribe',
			'<' . $unsubscribe_link . '>'
		);
	} else {
		$mail->addCustomHeader(
			'List-Unsubscribe',
			'<mailto:' . $replyto . '?subject=unsubscribe>,<' . $unsubscribe_link . '>'
		);
	}

	$mail->SMTPOptions = array(
		'ssl' => array(
			'verify_peer' => false,
			'verify_peer_name' => false,
			'allow_self_signed' => true
		)
	);


	try {
		$mail->send();
		// On success, queue index + delete
		$bulk[] = ['index' => ['_index' => 'sent_report']];
		$bulk[] = array_merge($src, [
			'email_message_id'    => trim($email_message_id, '<>'),
			'dateinfo'    => date('Y-m-d H:i:s'),
			'strdateinfo' => time(),
			'status'      => 'sent'
		]);
		$bulk[] = ['delete' => ['_index' => 'pending_mail_queue', '_id' => $id]];

		$mail_count++;
	} catch (Exception $e) {
		$errorInfo = $mail->ErrorInfo;
		echo ("<br />Send failed for $id: " . $mail->ErrorInfo);
		error_log("Send failed for $id: " . $mail->ErrorInfo);
		appendLog([
				'to'      => $to_email_decoded,
				'time'    => date('Y-m-d H:i:s'),
				'gateway' => 'phpmailer',
				'error'   => $errorInfo ?: null,
			]);
		continue;
	}
}

// close SMTP session
$mail->smtpClose();

// ——— Execute bulk ——————————————————————————————————————————————
if ($bulk) {
	$bresp = $esClient->bulk(['body' => $bulk]);
	if (!empty($bresp['errors'])) {
		error_log("Bulk errors: " . json_encode($bresp['items']));
	}
	$last_log = "Processed " . (count($bulk) / 3) . " records for " . $account_name;
	echo $last_log . ".<br />";
	appendLog([
				'recent_attempt'      => $last_log,
				'account_name' => $account_name
			]);
} else {
	echo "No records are processed (all failed).<br />";
}

releaseLock();
