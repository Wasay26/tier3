<?php
require __DIR__ . '/elastic/vendor/autoload.php';

// Set timezone & display errors
ini_set('date.timezone', 'Asia/Kolkata');
date_default_timezone_set('Asia/Kolkata');
ini_set('display_errors', 1);
error_reporting(E_ALL);

use Elasticsearch\ClientBuilder;

echo date("H:i:s") . "<br />";
// ─── ELASTICSEARCH CLIENT ──────────────────────────────────────────────────
$esClient = ClientBuilder::create()
	->setHosts(['https://elastic:Hary1011!@elastic.way2mail.in:9200'])
	->build();


//check maintenance
// Define the index to check
$maintenanceIndex = 'w2m_maintenance';

// Prepare count query to find documents with status=1
$countParams = [
	'index' => $maintenanceIndex,
	'body'  => [
		'query' => [
			'term' => [
				'status' => 1
			]
		]
	]
];

try {
	// Execute the count query
	$countResult = $esClient->count($countParams);

	// Get the count of documents with status=1
	$maintenanceCount = $countResult['count'] ?? 0;

	if ($maintenanceCount > 0) {
		echo "Maintenance work is going on<br />";
		exit;
		// You can add additional logic for when maintenance mode is on
	}
} catch (\Exception $e) {
	echo "Error checking maintenance status: " . $e->getMessage() . "<br />";
}

// ─── CONFIGURATION & CURSOR ─────────────────────────────────────────────────
$logfile      = '/tmp/postfix_lines.tmp';
$cursorFile   = __DIR__ . '/cursor.json';
$maxLines     = 1000;
$desired   = 10000;       // total lines you want to process


$today = date('Y-m-d');
$timenow = time();

// 1) Define your phrase buckets (all lowercase for substrings, regex for codes)
$phraseBuckets = [
	'Recipient Address Rejected' => ['recipient address rejected'],
	'Invalid Recipient'          => ['user unknown', 'no such user', '/\b5\.1\.1\b/'],
	'Mailbox Quota Full'       => ['mailbox full', 'quota exceeded', 'over quota', '/\b5\.2\.2\b/'],
	'Domain / Host Not Found'    => ['host not found', 'name or service not known', '/domain.*does not exist/'],
	'Connection Problem'       => ['connection timed out', 'connection refused', 'no route to host', 'network is unreachable', 'name service timeout', 'temporary failure in name resolution', '/\b4\.7\.0\b/'],
	'Message Too Large'          => ['message size exceeds fixed maximum', '/\b5\.3\.4\b/'],
	'Policy Denied'      => ['relay access denied', '/\b5\.7\.1\b/', '/policy.*blocked/'],
	'Spam Content'      => ['message content', 'detected as spam', '/\b5\.7\.5\b/', 'spam block'],
	'Greylist'         => ['try again later', 'greylist', '/\b4\.2\.0\b/', 'grey list'],
	'Syntax / Protocol Error'    => ['bad destination mailbox address', 'syntax error', '/\b5\.5\.2\b/'],
	'Temporary Failure'   => ['resource temporarily unavailable', '/\b4\.3\.[0-9]\b/'],

	// Extra categories:
	'TLS / SSL Errors'           => ['tls handshake failure', 'certificate verify failed', 'no cipher suites in common', 'ssl_connect error', 'unable to load certificate'],
	'Authentication / SASL'      => ['sasl authentication failed', '/\b535 5\.7\.8\b/', '/\b530 5\.7\.0\b/'],
	'Rate Limiting / Policy'     => ['too many connections', '/421 4\.7\.0.*policy rate limit/', '/451 4\.7\.1.*please try again later/', '/452 4\.3\.1.*mailbox has exceeded/'],
	'Loop Detection / Hop Limit' => ['too many hops', 'mail loop detected', '/554 5\.4\.4.*too many hops/'],
	'Address Formatting Errors'  => ['malformed address', 'illegal address', 'invalid domain literal', 'bad address syntax'],
	'DMARC/SPF/DKIM Failures'    => ['spf check failed', 'dkim verification failure', 'rejected due to dmarc policy'],
	'Spam Block'    => ['zen.spamhaus.org', 'spamhaus', 'barracuda', 'sorbs', 'spamcop', 'uribl', 'blacklist', 'proofpoint'],
	'Poor Reputation'    => ['poor reputation'],
];

$skipSenderBuckets  = ['Domain / Host Not Found', 'Greylist', 'Temporary Failure', 'Spam Content', 'Poor Reputation', 'Spam Block', 'DMARC/SPF/DKIM Failures', 'Policy Denied'];
$skipSenderPatterns = ['user unknown', 'greylist'];
$stopSendingBuckets = ['Domain / Host Not Found'];
$stopSendingPatterns = [];

function extractDomain(string $input): ?string
{
	// If it’s in “Name <email@domain>” format, grab the part inside <>
	if (preg_match('/<([^>]+)>/', $input, $m)) {
		$input = $m[1];
	}

	$input = trim($input);

	// Sanitize and validate as an email address
	$sanitized = filter_var($input, FILTER_SANITIZE_EMAIL);
	if (!filter_var($sanitized, FILTER_VALIDATE_EMAIL)) {
		return null;
	}

	// Split at the “@” and return the domain part
	[$localPart, $domain] = explode('@', $sanitized, 2);
	return $domain;
}


// ─── HELPERS ─────────────────────────────────────────────────────────────────
function extractEmail(string $input): string
{
	$input = trim($input);
	if (preg_match('/<([^>]+)>/', $input, $m)) {
		return $m[1];
	}
	return filter_var($input, FILTER_VALIDATE_EMAIL) ? $input : '';
}

/**
 * Clean and normalize header values based on header type.
 */
function cleanHeaderValue(string $type, string $value): string
{
	$value = trim($value);
	$lower = strtolower($type);
	switch ($lower) {
		case 'message-id':
			// Strip angle brackets
			return extractEmail($value);

		case 'from':
		case 'to':
		case 'reply-to':
			// Remove any trailing ' from ' part
			if (preg_match('/^(.*?)(?:\s+from\s|$)/i', $value, $m)) {
				return trim($m[1]);
			}
			return $value;

		case 'subject':
			// Strip anything after ' from '
			if (preg_match('/^(.*?)(?:\s+from\s|$)/i', $value, $m)) {
				$value = trim($m[1]);
			}
			// Decode MIME-encoded subjects if possible
			if (function_exists('iconv_mime_decode')) {
				return iconv_mime_decode($value, 0, 'UTF-8');
			}
			return $value;

		default:
			return $value;
	}
}

// ─── STEP 1: LOOKUP ACCOUNT ─────────────────────────────────────────────────
$fullDomain   = $_SERVER['HTTP_HOST'];
$accountField = isset($_REQUEST['account']) ? 'account_name.keyword' : 'website_root.keyword';
$accountValue = isset($_REQUEST['account']) ? trim($_REQUEST['account']) : $fullDomain;
try {
	$acctResp = $esClient->search([
		'index' => 'accounts',
		'size'  => 1,
		'body'  => ['query' => ['term' => [$accountField => $accountValue]]]
	]);
	$acct = $acctResp['hits']['hits'][0]['_source'] ?? null;
	if (!$acct) {
		exit("ERROR: No matching account for '{$accountValue}'<br />");
	}
	$account_name = $acct['account_name'];
	$website_root = $acct['website_root'];
} catch (\Exception $e) {
	exit("ERROR: Account lookup failed: {$e->getMessage()}<br />");
}

// ─── STEP 2: ENSURE INDICES ─────────────────────────────────────────────────
$linesIndex = 'postfix_lines';
$mailIndex  = 'postfix_mail_logs_v2';
$archiveIndex     = 'delivery_archive';

$mappingTemplate = [
	'settings' => ['number_of_shards' => 5, 'number_of_replicas' => 1],
	'mappings' => [
		'dynamic_templates' => [[
			'strings_as_text' => [
				'match_mapping_type' => 'string',
				'mapping'            => ['type' => 'text', 'fields' => ['keyword' => ['type' => 'keyword', 'ignore_above' => 256]]]
			]
		]],
		'properties' => []
	]
];

foreach ([$linesIndex, $mailIndex] as $idx) {
	if (!$esClient->indices()->exists(['index' => $idx])) {
		$mapping = $mappingTemplate;
		if ($idx === $linesIndex) {
			$mapping['mappings']['properties'] = [
				'queue_id'           => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'header_type'        => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'header_value'       => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'reference_id'       => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'header_time'        => ['type' => 'date',   'format' => 'yyyy-MM-dd HH:mm:ss'],
				'header_strdateinfo' => ['type' => 'long'],
				'account_name'       => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'website_root'       => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
			];
		} else {
			$mapping['mappings']['properties'] = [
				'queue_id'    => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'message_id'  => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'from'        => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'to'          => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'reply_to'    => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'subject'     => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'status'      => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'reason'      => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'sent_time'   => ['type' => 'date',   'format' => 'yyyy-MM-dd HH:mm:ss'],
				'log_date'   => ['type' => 'date',   'format' => 'yyyy-MM-dd'],
				'strdateinfo' => ['type' => 'long'],
				'account_name' => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
				'website_root' => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
			];
		}
		$esClient->indices()->create(['index' => $idx, 'body' => $mapping]);
	}
}

// now ensure the archive index
if (! $esClient->indices()->exists(['index' => $archiveIndex])) {
	$mapping = $mappingTemplate;
	$mapping['mappings']['properties'] = [
		// carry over any fields you need from sent_report…
		'strdateinfo'       => ['type' => 'long'],
		'campaign_date_str' => ['type' => 'long'],
		'status'            => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
		'log_date'          => ['type' => 'date',   'format' => 'yyyy-MM-dd'],
		'log'               => ['type' => 'text',   'fields' => ['keyword' => ['type' => 'keyword']]],
		// add anything else you want indexed in the archive…
	];
	$esClient->indices()->create(['index' => $archiveIndex, 'body' => $mapping]);
}



echo date("H:i:s") . "<br />";
// ─── STEP 3: READ LOG & UPDATE CURSOR ────────────────────────────────────────
$lastLine = 0;
if (file_exists($cursorFile)) {
	$data = json_decode(file_get_contents($cursorFile), true);
	$lastLine = (int)($data['lastLine'] ?? 0);
}
///////////////////////////////////////////////////////////////

// ─── READ UP TO $desired LINES ──────────────────────────────────────────────
$file = new SplFileObject($logfile, 'r');
$file->seek($lastLine);

$allLines = [];
for ($i = 0; $i < $desired && !$file->eof(); $i++, $file->next()) {
	$allLines[] = $file->current();
}

// advance cursor by however many lines we actually read
$filePos = $file->key();
file_put_contents($cursorFile, json_encode(['lastLine' => $filePos, 'last_updated_on' => date('Y-m-d H:i:s')], JSON_PRETTY_PRINT));
echo "Read " . count($allLines) . " lines; cursor now at {$filePos}<br />";

// ─── SPLIT INTO CHUNKS OF $maxLines ────────────────────────────────────────
$chunks = array_chunk($allLines, $maxLines);

// ─── PROCESS EACH CHUNK ───────────────────────────────────────────────────
foreach ($chunks as $batch => $lines) {
	// reset all per‐batch arrays
	$bulkLines          = [];
	$statusLines        = [];
	$headersByQid       = [];
	$bulkBody           = [];
	$mailEventsForArchive = [];


	echo "Batch: Read " . count($lines) . " lines<br />";
	if (!count($lines)) {
		echo "No more lines to process, stopping.<br />";
		break;
	}
	echo date("H:i:s") . "<br />";
	// ─── PASS 1: BULK INDEX HEADERS ──────────────────────────────────────────────
	foreach ($lines as $row) {
		$line = trim($row);
		if (preg_match('/^(\w+\s+\d+\s+\d{2}:\d{2}:\d{2}) .*?: ([A-F0-9]{10,}): info: header (From|To|Reply-To|Subject|Message-ID): (.*)/i', $line, $m)) {
			list(, $sysTs, $qid, $hdr, $val) = $m;
			$ts    = strtotime(date('Y') . " {$sysTs}") ?: time();
			$clean = cleanHeaderValue($hdr, $val);
			$ref   = strtolower($hdr) === 'message-id' ? $clean : '';
			// Use unique ID per queue_id and header type to overwrite previous headers
			$bulkLines[] = ['index' => ['_index' => $linesIndex, '_id' => $qid . '_' . strtolower($hdr)]];
			$bulkLines[] = [
				'queue_id'           => $qid,
				'header_type'        => $hdr,
				'header_value'       => $clean,
				'reference_id'       => $ref,
				'header_time'        => date('Y-m-d H:i:s', $ts),
				'header_strdateinfo' => (int)$ts,
				'account_name'       => $account_name,
				'website_root'       => $website_root
			];
		}
	}
	if ($bulkLines) {
		$esClient->bulk(['body' => $bulkLines]);
		$esClient->indices()->refresh(['index' => $linesIndex]);
		echo "✅ Bulk indexed headers:" . (count($bulkLines) / 2) . " docs<br />";
	}
	echo date("H:i:s") . "<br />";
	// ─── PASS 2: BUILD & BULK INDEX EVENTS (FIXED BULK FORMAT) ─────────────────

	// 1) Collect status‐lines
	$statusLines = [];
	foreach ($lines as $row) {
		if (preg_match(
			'/postfix\/.*?: ([A-F0-9]{10,}): .*status=(sent|bounced|deferred)(?: \((.*?)\))?/i',
			trim($row),
			$m
		)) {
			$statusLines[] = [
				'line'   => trim($row),
				'qid'    => $m[1],
				'status' => strtolower($m[2]),
				'reason' => $m[3] ?? '',
				'now'    => date('Y-m-d H:i:s'),
				'tsi'    => time(),
			];
		}
	}

	if (empty($statusLines)) {
		echo "No status lines to process in batch {$batch}<br />";
		exit;
	}

	// 2) Bulk‐fetch all headers for these queue_ids
	$qids = array_unique(array_column($statusLines, 'qid'));
	$qids = array_values(array_unique($qids));
	$headersByQid = [];
	$hdrResp = $esClient->search([
		'index' => $linesIndex,
		'size'  => count($qids) * 5,
		'body'  => [
			'query' => [
				'terms' => ['queue_id.keyword' => $qids]
			]
		]
	]);
	foreach ($hdrResp['hits']['hits'] as $hit) {
		$src = $hit['_source'];
		$headersByQid[$src['queue_id']][] = $src;
	}
	foreach ($headersByQid as &$hdrs) {
		usort($hdrs, fn($a, $b) => ($b['header_strdateinfo'] <=> $a['header_strdateinfo']));
	}
	unset($hdrs);


	// ─── STEP 2.5: LOAD SENDING PORTAL DOMAINS ────────────────────────────────────
	$portalMap = [];
	try {
		$resp = $esClient->search([
			'index' => 'sending_portal_domains',
			'size'  => 100,
			'body'  => ['query' => ['match_all' => (object)[]]]
		]);
		foreach ($resp['hits']['hits'] as $hit) {
			$src = $hit['_source'];
			// map domainname → sending_portal
			$portalMap[$src['domainname']] = $src['sending_portal'];
		}
	} catch (\Exception $e) {
		// if it fails, keep $portalMap empty and all events will get ''
		error_log("Failed loading sending_portal_domains: " . $e->getMessage());
	}

	// 3) Build bulk payload
	$bulkBody        = [];
	$mailEventsForArchive = [];

	foreach ($statusLines as $s) {
		$qid = $s['qid'];
		if (empty($headersByQid[$qid])) {
			continue;
		}

		$matchedPhrases = [];
		$matchedPhrasesPatterns = [];
		$skip_same_sender = 0;
		$do_not_send = 0;
		$logLower = strtolower($s['line']);
		foreach ($phraseBuckets as $bucket => $patterns) {
			foreach ($patterns as $pattern) {
				$isRegex = (substr($pattern, 0, 1) === '/' && substr($pattern, -1) === '/');
				if ($isRegex) {
					if (preg_match($pattern, $logLower, $m)) {
						$matchedPhrases[] = $bucket;
						$matchedPhrasesPatterns[] = $m[0];
						break;  // stop after first match in this bucket
					}
				} else {
					$needle = strtolower($pattern);
					if (strpos($logLower, $needle) !== false) {
						$matchedPhrases[] = $bucket;
						$matchedPhrasesPatterns[] = $pattern;
						break;  // stop after first match in this bucket
					}
				}
			}
		}
		$matchedPhrases = array_values(array_unique($matchedPhrases));
		$matchedPhrasesPatterns = array_values(array_unique($matchedPhrasesPatterns));

		if (
			count(array_intersect($matchedPhrases,  $skipSenderBuckets))  > 0 ||
			count(array_intersect($matchedPhrasesPatterns, $skipSenderPatterns)) > 0
		) {
			$skip_same_sender = 1;
		}

		if (
			count(array_intersect($matchedPhrases,  $stopSendingBuckets))  > 0 ||
			count(array_intersect($matchedPhrasesPatterns, $stopSendingPatterns)) > 0
		) {
			$do_not_send = 1;
		}


		// Base event
		$event = [
			'queue_id'     => $qid,
			'message_id'   => '',
			'status'       => $s['status'],
			'reason'       => $s['reason'],
			'sent_time'    => $s['now'],
			'strdateinfo'  => $s['tsi'],
			'account_name' => $account_name,
			'website_root' => $website_root,
			'sender_email'   => '',
			'from_email'     => '',
			'from_domain'      => '',
			'to_email'       => '',
			'to_domain'      => '',
			'reply_to_email' => '',
			'sending_portal' => '',
			'subject'        => '',
			'log_date'       => $today,
			'log'            => $s['line'],
			'logdateinfo'       => $timenow,
			'phrases'      => $matchedPhrases,
			'phrases_patterns'      => $matchedPhrasesPatterns,
			'skip_same_sender' => $skip_same_sender,
			'do_not_send' => $do_not_send,
		];

		// Fill from headers
		$fields = ['message_id' => false, 'from' => false, 'to' => false, 'reply_to' => false, 'subject' => false];
		foreach ($headersByQid[$qid] as $h) {
			$type  = strtolower($h['header_type']);
			$value = $h['header_value'];

			if (!$fields['message_id'] && $type === 'message-id' && $h['reference_id']) {
				$event['message_id'] = $h['reference_id'];
				$fields['message_id'] = true;
			}
			if (!$fields['from'] && $type === 'from') {
				$event['sender_email'] = extractEmail($value);
				$fields['from'] = true;
			}
			if (!$fields['to'] && $type === 'to') {
				$event['to_email']  = extractEmail($value);
				$event['to_domain'] = $event['to_email'] ? extractDomain($event['to_email']) : '';
				$fields['to'] = true;
			}
			if (!$fields['reply_to'] && $type === 'reply-to') {
				$event['reply_to_email'] = extractEmail($value);
				$event['from_email'] = $event['reply_to_email'];
				$fromDomain = $event['from_email'] ? extractDomain($event['from_email']) : '';
				$event['from_domain'] = $fromDomain;
				$event['sending_portal'] = $portalMap[$fromDomain] ?? '';
				$fields['reply_to'] = true;
			}
			if (!$fields['subject'] && $type === 'subject') {
				$event['subject'] = $value;
				$fields['subject'] = true;
			}
			if (!in_array(false, $fields, true)) {
				break;
			}
		}

		// Only index valid events
		if ($event['message_id'] && $event['to_email']) {
			// Deterministic ID to dedupe
			// instead of raw concatenation:
			$rawId = "{$event['message_id']}|{$event['to_email']}|{$event['status']}";

			// use md5 (or sha1, etc.) to get a safe fixed-length string:
			$docId = md5($rawId);
			// Action line
			$bulkBody[] = [
				'index' => [
					'_index' => $mailIndex,
					'_id'    => $docId
				]
			];
			// Source line
			$bulkBody[] = $event;

			// Queue for archive lookup
			$mailEventsForArchive[] = $event;
			/*
			if ($event['status'] !== 'deferred') {
				$mailEventsForArchive[] = $event;
			}
			*/
		}
	}

	// 4) Send mail logs bulk
	if ($bulkBody) {
		$esClient->bulk(['body' => $bulkBody]);
		echo "✅ Bulk inserted events: " . (count($bulkBody) / 2) . " docs<br />";
	}

	// 5) ARCHIVE lookup & bulk
	if (!empty($mailEventsForArchive)) {
		// Build lookup IDs
		// Build lookup IDs
		$lookupIds = [];
		foreach ($mailEventsForArchive as $e) {
			$lookupIds[] = $e['message_id'];
			$lookupIds[] = "<{$e['message_id']}>";
		}
		$lookupIds = array_values(array_unique($lookupIds));  // ← re-index here

		// Now your terms query will be treated as a list, not a lookup
		$sentResp = $esClient->search([
			'index' => ['sent_report', 'sent_archive'],
			'size'  => count($lookupIds),
			'body'  => [
				'query' => [
					'bool'   => [
						'filter' => [
							[
								'terms' => [
									'email_message_id.keyword' => $lookupIds
								]
							]
						]
					]
				]
			]
		]);

		// Map by trimmed ID
		$sentMap = [];
		foreach ($sentResp['hits']['hits'] as $hit) {
			$src = $hit['_source'];
			$key = trim($src['email_message_id'], '<>');
			$sentMap[$key] = $src;
		}

		// Build archive bulk
		$arcBody = [];
		foreach ($mailEventsForArchive as $e) {
			$mid = $e['message_id'];
			if (isset($sentMap[$mid])) {
				$doc = array_merge($sentMap[$mid], [
					'status'           => $e['status'],
					'log_date'         => $today,
					'log'              => $e['log'],
					'reason'           => $e['reason'],
					'phrases'          => $e['phrases'],
					'phrases_patterns' => $e['phrases_patterns'],
					'skip_same_sender' => $e['skip_same_sender'],
					'do_not_send' 	   => $e['do_not_send'],
					'logdateinfo'      => $timenow,
					'email_message_id' => $mid,
				]);
				$arcBody[] = ['index' => ['_index' => $archiveIndex, '_id' => $doc['email_message_id']]];
				$arcBody[] = $doc;
			}
		}

		if ($arcBody) {
			$esClient->bulk(['body' => $arcBody]);
			echo "✅ Archived deliveries: " . (count($arcBody) / 2) . " docs<br />";
		}
	}
}

echo date("H:i:s") . "<br />";
