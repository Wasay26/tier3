<?php
date_default_timezone_set('UTC'); // Set timezone to UTC

// Configurations
define('CIPHER_METHOD', 'AES-128-CTR');
define('ENCRYPTION_IV', '1234567891234567');
define('ENCRYPTION_KEY', 'sfbfgbfgbcfgbfgdbfgdbfrgbfgdbgfbgfbfgdgbffgbfgb');
define('DB_HOST', '119.18.62.48');
define('DB_USER', 'review1_md');
define('DB_PASS', 'Mdomain@890');
define('DB_NAME', 'review1_md');
define('ENDPOINT', 'review1.in');
define('CACHE_DIR', './cache/');

// Redirect function
function redirectTo($url, $statusCode = 302) {
    header('Location: ' . $url, true, $statusCode);
    exit;
}

// Helper functions
function encrypt($token) {
    $encrypted = openssl_encrypt($token, CIPHER_METHOD, ENCRYPTION_KEY, 0, ENCRYPTION_IV);
    return strtr($encrypted, '+/=', '._-');
}

function decrypt($token) {
    $decodedToken = strtr($token, '._-', '+/=');
    return openssl_decrypt($decodedToken, CIPHER_METHOD, ENCRYPTION_KEY, 0, ENCRYPTION_IV);
}

function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode($data) {
    return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
}

function getClientIp() {
    foreach (['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'] as $key) {
        if (isset($_SERVER[$key])) return $_SERVER[$key];
    }
    return 'UNKNOWN';
}

// Retrieves data from cache or database
function fetchUrlData($idField, $idValue) {
    $cacheFile = CACHE_DIR . 'backup_' . $idValue . '.json';
    if (file_exists($cacheFile) && $cacheData = json_decode(file_get_contents($cacheFile), true)) {
        return !empty($cacheData['site_name']) ? $cacheData : null;
    }

    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $stmt = $pdo->prepare("SELECT * FROM `masking_urls` WHERE {$idField} = :id");
        $stmt->execute(['id' => $idValue]);
        if ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
            file_put_contents($cacheFile, json_encode($result));
            return $result;
        }
    } catch (PDOException $e) {
        $response = file_get_contents("https://" . ENDPOINT . "/?$idValue&json");
        return $response ? json_decode($response, true) : [];
    }
}

// Log recipient opening event
function logOpens($r, $response, $rcol) {
    $redirect_destination=$response['redirect_destination'] ?? '';
    $site_domain=$response['site_domain'] ?? '';
    $site_name=$response['site_name'] ?? '';
    $campaign_name=$response['campaign_name'] ?? '';
    $campaignid=$response['campaignid'] ?? '';
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        if (strpos($redirect_destination, 'read.png') !== false) {
            $stmt = $pdo->prepare("INSERT INTO `email_opened` (".$rcol.", opened_at, ip_address, redirect_destination, site_domain, site_name, campaign_name, campaignid) VALUES (:r, :opened_at, :ip_address, :redirect_destination, :site_domain, :site_name, :campaign_name, :campaignid)");
        }else{
            $stmt = $pdo->prepare("INSERT INTO `links_opened` (".$rcol.", opened_at, ip_address, redirect_destination, site_domain, site_name, campaign_name, campaignid) VALUES (:r, :opened_at, :ip_address, :redirect_destination, :site_domain, :site_name, :campaign_name, :campaignid)");
        }
        
        $stmt->execute([
            'r' => $r,            
            'opened_at' => date('Y-m-d H:i:s'), // current UTC time
            'ip_address' => getClientIp(),
            'redirect_destination' => addslashes($redirect_destination),
            'site_domain' => $site_domain,
            'site_name' => $site_name,
            'campaign_name' => $campaign_name,
            'campaignid' => $campaignid
        ]);
    } catch (PDOException $e) {
        // Log error or handle it as needed
    }
}

// Main logic
$current_url_pcs = explode('/', trim($_SERVER['REQUEST_URI'], '/'));
$param_1 = $current_url_pcs[0] ?? '';
$param_2 = $current_url_pcs[1] ?? '';
$param_3 = $current_url_pcs[2] ?? ''; // expected to be email address if present

if (!empty($param_2) && $param_2[0] !== '?') {
    $response = fetchUrlData('link_token', $param_2);
    if (!empty($response['redirect_destination'])) {
        // Check if $param_3 is a valid email and log it
        if (filter_var($param_3, FILTER_VALIDATE_EMAIL)) {
            logOpens($param_3, $response, 'recipient');
        } elseif (ctype_digit($param_3)) {
            logOpens($param_3, $response, 'list_data_id');
        }
        redirectTo($response['redirect_destination'], 301);
        exit;
    }
    
    if (strpos($_SERVER['REQUEST_URI'], '/?') !== false) {
        $request=array_keys($_REQUEST);
        if(isset($request[0])){    
            $crypted_token=ltrim(urldecode($_SERVER['REQUEST_URI']),"/?");    
            file_put_contents("logs.txt",urldecode($_SERVER['REQUEST_URI']).PHP_EOL,FILE_APPEND);
            $originaltoken_copy=$crypted_token;
            if($crypted_token!=""){
                $crypted_token=explode("&",$crypted_token)[0];
            }
            $crypted_token=str_replace("%20","+",$crypted_token);
            $crypted_token=str_replace(" ","+",$crypted_token);    
            $final_destination=decrypt($crypted_token);
            redirectTo($final_destination);
        }
    }
    exit;
}

$request = array_keys($_REQUEST);
if (!empty($request[0])) {
    $crypted_token = str_replace(["%20", " "], "+", explode("&", urldecode($_SERVER['REQUEST_URI']))[0]);
    file_put_contents("logs.txt", urldecode($_SERVER['REQUEST_URI']) . PHP_EOL, FILE_APPEND);
    
    if (isset($_GET['ur'])) {
        $response = fetchUrlData('ID', decrypt($crypted_token));
        if (!empty($response['redirect_destination'])) {
            // Check if $param_3 is a valid email and log it
            if (filter_var($param_3, FILTER_VALIDATE_EMAIL)) {
                logOpens($param_3, $response, 'recipient');
            } elseif (ctype_digit($param_3)) {
                logOpens($param_3, $response, 'list_data_id');
            }
            redirectTo($response['redirect_destination'], 301);
        }

        $title = $response['site_name'] ?? 'Please Wait';
        $post_panel = $response['site_domain'] ?? '';
    } else {
        
        $final_destination = isset($_REQUEST['bs4']) ? base64url_decode($crypted_token) : decrypt($crypted_token);
    }

    ?>
    <html>
    <head>
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-R5K20JCF72"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-R5K20JCF72');
            <?php if (isset($response)): ?>
                gtag('set', {
                    'campaign_name': '<?= strtolower(str_replace([" ", "(", ")"], ["-", "-", "-"], trim($response['campaign_name']))) ?>',
                    'campaign_source': '<?= strtolower(str_replace(" ", "_", $response['site_name'] ?? '')) ?>',
                    'campaign_medium': 'email',
                    'campaign_term': '<?= strtolower(str_replace(".", "-", $response['site_domain'] ?? '')) ?>',
                    'campaign_id': '<?= $response['campaignid'] ?? '' ?>',
                });
            <?php endif; ?>
        </script>
        <title><?= $title ?? 'Please Wait' ?></title>
        <link href="https://fonts.googleapis.com/css?family=Titillium+Web&display=swap" rel="stylesheet">
    </head>
    <body>
        <?php if (!empty($response['redirect_destination']) || !empty($final_destination)): ?>
            <script>
                setTimeout(function() { 
                    window.location.href="<?= $response['redirect_destination'] ?? $final_destination ?>";
                }, 500);
            </script>
        <?php else: ?>
            <script src="//<?= ENDPOINT ?>?<?= $crypted_token ?>"></script>
        <?php endif; ?>
    </body>
    </html>
    <?php
    exit;
}
?>
