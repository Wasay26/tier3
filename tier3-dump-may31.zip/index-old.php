<?php
date_default_timezone_set('Asia/Kolkata');
function redirectTo($url, $statusCode = 302) {
    try {
        header('Location: ' . $url, true, $statusCode);
        exit;
    } catch(Exception $e) {
        return true;
    }    
}
/*
function add2htaccess($f,$t){
    if (file_exists(".htaccess")) {
        file_put_contents(".htaccess",'RedirectMatch 301 ^/?'.$f.'(.*) '.$t.''.PHP_EOL,FILE_APPEND);
    }else{
        file_put_contents(".htaccess",'RewriteEngine On'.PHP_EOL,FILE_APPEND);
        file_put_contents(".htaccess",'RedirectMatch 301 ^/?'.$f.'(.*) '.$t.''.PHP_EOL,FILE_APPEND);
    }
}
*/
$current_url=$_SERVER['REQUEST_URI'];
$current_url_pcs=explode('/',$current_url);
$param_1="";
$param_2="";
if(sizeof($current_url_pcs)>1){
    if(isset($current_url_pcs[1])){
        $param_1=$current_url_pcs[1];        
    }
    if(isset($current_url_pcs[2])){
        $param_2=$current_url_pcs[2];        
    }
}
$post_panel="";
$title="Please Wait";
$endpoint="review1.in";
function w2m_encrypt($token){
	$ciphering_value = "AES-128-CTR";   
	$iv_length = openssl_cipher_iv_length($ciphering_value);  
	$options = 0;  
	$encryption_iv_value = '1234567891234567';  
	$key = "sfbfgbfgbcfgbfgdbfgdbfrgbfgdbgfbgfbfgdgbffgbfgb";  
	$encryption_value = openssl_encrypt($token, $ciphering_value, $key, $options,$encryption_iv_value); 
	$encryption_value=strtr($encryption_value, '+/=', '._-');
	return $encryption_value;
}

function w2m_decrypt($token){
	$token=strtr($token, '._-', '+/=');
	$ciphering_value = "AES-128-CTR";   
	$iv_length = openssl_cipher_iv_length($ciphering_value);  
	$options = 0;  
	$encryption_iv_value = '1234567891234567';  
	$key = "sfbfgbfgbcfgbfgdbfgdbfrgbfgdbgfbgfbfgdgbffgbfgb";  
	$decryption_value = openssl_decrypt($token, $ciphering_value, $key, $options,$encryption_iv_value);   	
	return $decryption_value;
}

function base64url_encode($data) {
	return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode($data) {
	return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
}

function get_client_ip() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}
  

function url_register_out($url_token){
    global $endpoint;
	$response=[];
	$response['token']=$url_token;
	$w2m_host="119.18.62.48";
	$w2m_dbuser="review1_md";
	$w2m_dbpassword="Mdomain@890";
	$w2m_dbname="review1_md";
	$url_token_id=w2m_decrypt($url_token);

    $backup_file = './cache/backup_'.$url_token_id.'.json';

    if(file_exists($backup_file)){
        $backup_content=file_get_contents($backup_file);
        if($backup_content!=""){
            $response=json_decode($backup_content,TRUE);
            if(isset($response['site_name']) && $response['site_name']!=""){
                return $response;
            }
        }
    }    

	try {
		$w2m_ur = new PDO("mysql:host=".$w2m_host.";dbname=".$w2m_dbname, $w2m_dbuser, $w2m_dbpassword);
		$w2m_ur->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		// echo "Connected successfully";

		$check_url_q=$w2m_ur->query("SELECT * FROM `masking_urls` WHERE ID='".$url_token_id."'");
		if($check_url_q->rowCount()==0){
			//could not find
		}else{			
			$check_url_r=$check_url_q->fetch();
			$response['redirect_destination']=$check_url_r['redirect_destination'];
			$response['site_domain']=$check_url_r['site_domain'];
			$response['site_name']=$check_url_r['site_name'];
			$response['campaign_name']=$check_url_r['campaign_name'];
			$response['campaignid']=$check_url_r['campaignid'];			
		}

	  } catch(PDOException $e) {
		//echo "Connection failed: " . $e->getMessage();
		$json_response=file_get_contents("https://".$endpoint."/?".$url_token."&json");
        if($json_response!=""){
            $response=json_decode($json_response,TRUE);
        }
	  }
       
    file_put_contents($backup_file, json_encode($response));
	return $response;
}

function decode_link_token($link_token){
    global $endpoint;
	$response=[];
	$response['token']=$url_token;
	$w2m_host="119.18.62.48";
	$w2m_dbuser="review1_md";
	$w2m_dbpassword="Mdomain@890";
	$w2m_dbname="review1_md";

    $backup_file = './cache/backup_'.$link_token.'.json';

    if(file_exists($backup_file)){
        $backup_content=file_get_contents($backup_file);
        if($backup_content!=""){
            $response=json_decode($backup_content,TRUE);
            if(isset($response['site_name']) && $response['site_name']!=""){
                return $response;
            }
        }
    }    

	try {
		$w2m_ur = new PDO("mysql:host=".$w2m_host.";dbname=".$w2m_dbname, $w2m_dbuser, $w2m_dbpassword);
		$w2m_ur->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		// echo "Connected successfully";

		$check_url_q=$w2m_ur->query("SELECT * FROM `masking_urls` WHERE link_token='".addslashes($link_token)."'");
		if($check_url_q->rowCount()==0){
			//could not find
		}else{			
			$check_url_r=$check_url_q->fetch();
			$response['redirect_destination']=$check_url_r['redirect_destination'];
			$response['site_domain']=$check_url_r['site_domain'];
			$response['site_name']=$check_url_r['site_name'];
			$response['campaign_name']=$check_url_r['campaign_name'];
			$response['campaignid']=$check_url_r['campaignid'];			
		}

	  } catch(PDOException $e) {
		//echo "Connection failed: " . $e->getMessage();
		$json_response=file_get_contents("https://".$endpoint."/?".$link_token."&json");
        if($json_response!=""){
            $response=json_decode($json_response,TRUE);
        }
	  }
       
    file_put_contents($backup_file, json_encode($response));
	return $response;
}

if($param_2!="" && substr($param_2, 0, 1)!="?"){
    $response=decode_link_token($param_2);
    if(isset($response['redirect_destination']) && $response['redirect_destination']!=""){
        // add2htaccess($crypted_token,$response['redirect_destination']);
        redirectTo($response['redirect_destination'], 301); //force redirection
    }
    exit;
}

$request=array_keys($_REQUEST);
if(isset($request[0])){    
    $crypted_token=ltrim(urldecode($_SERVER['REQUEST_URI']),"/?");    
    file_put_contents("logs.txt",urldecode($_SERVER['REQUEST_URI']).PHP_EOL,FILE_APPEND);
    $originaltoken_copy=$crypted_token;
    if($crypted_token!=""){
        $crypted_token=explode("&",$crypted_token)[0];
    }
    $crypted_token=str_replace("%20","+",$crypted_token);
    $crypted_token=str_replace(" ","+",$crypted_token);    

/*
    if(isset($_GET['p'])){
        $p=str_replace(" ","+",$_GET['p']);
        
        $p=str_replace("%20","+",$p);
        if(isset($_REQUEST['bs4'])){    
            $post_panel=base64url_decode($p);
        }else{
            $post_panel=w2m_decrypt($p);
        }
    }
    
    if($post_panel!=""){
        $title=$post_panel;
    }
    
    if($post_panel!=""){
        $regex = preg_match('/[^A-Z_\d.\-]/i', $post_panel);
        if(!$regex){
            $title=$post_panel;
        }
    }
*/

if(isset($_GET['ur'])){
    $response=url_register_out($crypted_token);
    if(isset($response['redirect_destination']) && $response['redirect_destination']!=""){
        // add2htaccess($crypted_token,$response['redirect_destination']);
        redirectTo($response['redirect_destination'], 301); //force redirection
    }
    
    if(isset($response['site_name'])){
        $title=$response['site_name'];
    }
    if(isset($response['site_domain'])){
        $post_panel=$response['site_domain'];
    }
    // if($title=="Please Wait"){
    //     file_put_contents("logs.txt",urldecode($_SERVER['REQUEST_URI']).PHP_EOL,FILE_APPEND);
    // }
    ?>
    <html>
    <head>
        <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-R5K20JCF72"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-R5K20JCF72');
            gtag('set', {
                'campaign_name': '<?=strtolower(str_replace(")","-",str_replace("(","-",str_replace(" ","-",trim($response['campaign_name'])))))?>',
                'campaign_source': '<?=strtolower(str_replace(" ","_",$response['site_name']))?>',
                'campaign_medium': 'email',
                'campaign_term': '<?=strtolower(str_replace(".","-",$response['site_domain']))?>',
                'campaign_id': '<?=$response['campaignid']?>',
            });
        </script>
        <title><?=$title?></title>
        <link href="https://fonts.googleapis.com/css?family=Titillium+Web&display=swap" rel="stylesheet">
    </head>
    <body>
        <?php
        
        if(isset($response['redirect_destination'])){
            // file_put_contents("logs.txt",$_SERVER['REQUEST_URI'].PHP_EOL.$response['redirect_destination'].PHP_EOL,FILE_APPEND);
            ?>	
                <script>
                    setTimeout(function(){ 
                    window.location.href="<?=$response['redirect_destination']?>";
                }, 500);
                </script>
            <?php
        }else{
            // file_put_contents("logs.txt",$_SERVER['REQUEST_URI'].PHP_EOL."https://".$endpoint."?".$originaltoken_copy.PHP_EOL,FILE_APPEND);
            ?>
                <script src="//<?=$endpoint?>?<?=$originaltoken_copy?>"></script>
        <?php
        }
        ?>
    </body>
    </html>
    <?php
    exit;
}else{
    if(isset($_REQUEST['bs4'])){    
        $final_destination=base64url_decode($crypted_token);
    }else{
        $final_destination=w2m_decrypt($crypted_token);
    }
    
    // file_put_contents("logs.txt",$_SERVER['REQUEST_URI'].PHP_EOL.$final_destination.PHP_EOL.$post_panel.PHP_EOL,FILE_APPEND);
    
    //if($title=="Please Wait"){
    //    file_put_contents("logs.txt","Please Wait 2: ".urldecode($_SERVER['REQUEST_URI']).PHP_EOL,FILE_APPEND);
    //}
    ?>
<html>
<head>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-R5K20JCF72"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-R5K20JCF72');
</script>
<title><?=$title?></title>
 <link href="https://fonts.googleapis.com/css?family=Titillium+Web&display=swap" rel="stylesheet">
<?php if($final_destination!=""){
 echo '<meta http-equiv="refresh" content="0;URL='.$final_destination.'"/>';
 } ?>
</head>
<body onload="myFunction()">
<?php if($final_destination!=""){ ?>
    <script>
        function myFunction() {
        setTimeout(function(){ 
            window.location.href="<?=$final_destination?>";
        }, 500);
        }
    </script>
<?php } ?>
</body>
</html>
<?php
}

exit;
}